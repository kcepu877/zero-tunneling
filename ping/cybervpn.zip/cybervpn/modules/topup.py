from cybervpn import *
from telethon import events, Button
import random
import sys
from datetime import datetime, timedelta
import asyncio
import time

def get_admin_chat_id_from_db():
    """Fungsi untuk mendapatkan admin chat ID dari database"""
    try:
        db = get_db()
        result = db.execute("SELECT user_id FROM user WHERE level = 'admin'").fetchone()
        if result:
            return result[0]  # Mengembalikan user_id admin
        return None
    except Exception as e:
        print(f"Error getting admin chat ID: {e}")
        return None
    finally:
        if 'db' in locals():
            db.close()

async def main(event):
    durasi = 180
    print("Timer dimulai untuk 3 menit.")
    await asyncio.sleep(durasi)
    await event.respond("Waktu transaksi sudah  habis!")

@bot.on(events.CallbackQuery(data=b'topup'))
async def topup_user(event):
    async def topup_user_(event):
        random_numbers = [random.randint(0, 99) for _ in range(3)]
        async with bot.conversation(chat) as nominal_conv:
            await event.edit('**Input nominal topup:**')
            nominal_msg = await nominal_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            nominal = int(nominal_msg.raw_text.strip()) if nominal_msg.raw_text.strip().isdigit() else 0

        if nominal < 10000:
            await event.respond("**Nominal tidak memenuhi syarat. minimal transaksi RP.10.000.**")
            sys.exit()  
        else:
            result = sum(random_numbers) + nominal
            waktu_awal = datetime.now()
            waktu_expired = waktu_awal + timedelta(minutes=1)
        try:
            dana_gopay_list = tampilkan_dana_gopay()

            if dana_gopay_list:
                dana_gopay_str = "\n".join(dana_gopay_list)
                msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**     🕊 Informasi Pembayaran 🕊**
**◇━━━━━━━━━━━━━━━━━◇**
{dana_gopay_str}
**◇━━━━━━━━━━━━━━━━━◇**
** Nominal yang harus di bayar:**
** TRX:** RP.`{result}`
** Kode transaksi:** `{sum(random_numbers)}`
** Waktu transaksi hanya 3 menit**
** Waktu transaksi: {waktu_awal.strftime("%H:%M:%S")}**
** Expired transaksi: {waktu_expired.strftime("%H:%M:%S")}**
**◇━━━━━━━━━━━━━━━━━◇**
**Notice:** Setelah melakukan topup, harap kirim bukti transfer ke admin @WendiVpn
 untuk mempercepat proses transaksi!
**◇━━━━━━━━━━━━━━━━━◇**
                """
                buttons = [[Button.inline("‹ Menu ›", "menu")]]
                await event.respond(msg, buttons=buttons)
                await main(event)
                
                # Notifikasi untuk admin
                admin_chat_id = get_admin_chat_id_from_db()
                if admin_chat_id:
                    notification_msg = f"Topup baru dari {sender.username} (ID: {user_id}): RP.{result}, Kode transaksi: {sum(random_numbers)}"
                    buttons = [
                        [Button.inline("✅ Konfirmasi", f"confirm_{user_id}_{result}"),
                         Button.inline("❌ Tolak", f"reject_{user_id}")]
                    ]
                    await bot.send_message(admin_chat_id, notification_msg, buttons=buttons)
                else:
                    print("Warning: Admin chat ID tidak ditemukan")
            else:
                await event.respond("Data pengguna tidak tersedia saat ini.")

        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"Terjadi kesalahan: {e}")

@bot.on(events.CallbackQuery)
async def handle_confirmation(event):
    data = event.data.decode('utf-8')
    user_id, result = data.split('_')[1], int(data.split('_')[2]) if 'confirm' in data else (None, None)

    if 'confirm' in data:
        tambah_saldo(user_id, result)  # Tambah saldo jika dikonfirmasi
        await event.respond("Saldo telah ditambahkan.")
    elif 'reject' in data:
        await event.respond("Topup ditolak, saldo tidak ditambahkan.")

